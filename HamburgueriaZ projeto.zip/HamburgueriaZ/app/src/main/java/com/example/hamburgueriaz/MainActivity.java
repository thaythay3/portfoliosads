package com.example.hamburgueriaz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edtNomeCliente;
    private CheckBox cbBacon, cbQueijo, cbOnionRings;
    private TextView txtQuantidade, txtResumoPedido;
    private Button btnSomar, btnSubtrair, btnEnviarPedido;

    private int quantidade = 1;
    private final int PRECO_BASE = 20;
    private final int PRECO_BACON = 2;
    private final int PRECO_QUEIJO = 2;
    private final int PRECO_ONION = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando as views
        edtNomeCliente   = findViewById(R.id.edtNomeCliente);
        cbBacon          = findViewById(R.id.cbBacon);
        cbQueijo         = findViewById(R.id.cbQueijo);
        cbOnionRings     = findViewById(R.id.cbOnionRings);
        txtQuantidade    = findViewById(R.id.txtQuantidade);
        txtResumoPedido  = findViewById(R.id.txtResumoPedido);
        btnSomar         = findViewById(R.id.btnSomar);
        btnSubtrair      = findViewById(R.id.btnSubtrair);
        btnEnviarPedido  = findViewById(R.id.btnEnviarPedido);

        // Botão "+"
        btnSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                somar();
            }
        });

        // Botão "-"
        btnSubtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subtrair();
            }
        });

        // Botão "Enviar Pedido"
        btnEnviarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarPedido();
            }
        });
    }

    // Etapa 5: Função somar
    private void somar() {
        quantidade++;
        txtQuantidade.setText(String.valueOf(quantidade));
    }

    // Etapa 5: Função subtrair (não permite quantidade negativa)
    private void subtrair() {
        if (quantidade > 1) {
            quantidade--;
            txtQuantidade.setText(String.valueOf(quantidade));
        } else {
            Toast.makeText(this, "A quantidade não pode ser menor que 1", Toast.LENGTH_SHORT).show();
        }
    }

    // Etapa 6 e 7: Função enviarPedido
    private void enviarPedido() {
        // Identifica o nome do cliente
        String nomeCliente = edtNomeCliente.getText().toString().trim();
        if (nomeCliente.isEmpty()) {
            nomeCliente = "Cliente";
        }

        // Identifica os adicionais selecionados
        boolean temBacon      = cbBacon.isChecked();
        boolean temQueijo     = cbQueijo.isChecked();
        boolean temOnionRings = cbOnionRings.isChecked();

        // Calcula o preço total
        int precoTotal = calcularPrecoTotal(temBacon, temQueijo, temOnionRings);

        // Monta o resumo do pedido
        String resumo = "Nome do cliente: " + nomeCliente + "\n" +
                "Tem Bacon? "       + (temBacon      ? "Sim" : "Não") + "\n" +
                "Tem Queijo? "      + (temQueijo     ? "Sim" : "Não") + "\n" +
                "Tem Onion Rings? " + (temOnionRings ? "Sim" : "Não") + "\n" +
                "Quantidade: "      + quantidade + "\n" +
                "Preço final: R$ "  + precoTotal;

        // Exibe o resumo na view
        txtResumoPedido.setText(resumo);

        // Etapa 7: Intent ACTION_SENDTO para abrir o aplicativo de e-mail
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // Somente apps de e-mail tratam este intent
        intent.putExtra(Intent.EXTRA_SUBJECT, "Pedido de " + nomeCliente);
        intent.putExtra(Intent.EXTRA_TEXT, resumo);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "Nenhum aplicativo de e-mail encontrado.", Toast.LENGTH_SHORT).show();
        }
    }

    // Função auxiliar para calcular o preço total
    private int calcularPrecoTotal(boolean temBacon, boolean temQueijo, boolean temOnionRings) {
        int precoUnitario = PRECO_BASE;

        if (temBacon)      precoUnitario += PRECO_BACON;
        if (temQueijo)     precoUnitario += PRECO_QUEIJO;
        if (temOnionRings) precoUnitario += PRECO_ONION;

        return precoUnitario * quantidade;
    }
}
